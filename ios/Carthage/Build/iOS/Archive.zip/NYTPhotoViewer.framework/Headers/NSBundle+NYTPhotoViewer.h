//
//  NSBundle+NYTPhotoViewer.h
//  NYTPhotoViewer
//
//  Created by Chris Dzombak on 10/16/15.
//
//

@import Foundation;

@interface NSBundle (NYTPhotoViewer)

+ (instancetype)nyt_photoViewerResourceBundle;

@end
